var indexSectionsWithContent =
{
  0: "bcdefghilprsuw",
  1: "bcls",
  2: "cdfgilprsuw",
  3: "defhrw",
  4: "el",
  5: "el",
  6: "bdefs"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Enumerations",
  6: "Macros"
};

