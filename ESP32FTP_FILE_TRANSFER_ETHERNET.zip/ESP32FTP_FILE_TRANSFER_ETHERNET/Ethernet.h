#ifndef __ETHERNET_H
#define __ETHERNET_H
#include <ETH.h>
#define SDCARD_LOG

#ifdef SDCARD_LOG
#define EthernetLog(...) Serial.print(__VA_ARGS__)
#define EthernetLogLn(...) Serial.println(__VA_ARGS__)
#define EthernetLogF(...) Serial.printf(__VA_ARGS__)
#else
#define EthernetLog(...)
#define EthernetLogLn(...)
#define EthernetLogF(...)
#endif


extern bool eth_connected;

void initEthernet();


#endif
