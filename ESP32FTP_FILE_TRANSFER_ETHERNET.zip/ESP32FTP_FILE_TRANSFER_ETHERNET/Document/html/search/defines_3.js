var searchData=
[
  ['ftp_5flog',['FTP_Log',['../simple__ftp__client_8h.html#a1ffea06febf575b95a891ff135330622',1,'simple_ftp_client.h']]]
];
