#include "Ethernet.h"

bool eth_connected = false;

void WiFiEvent(WiFiEvent_t event)
{
  switch (event) {
    case SYSTEM_EVENT_ETH_START:
      EthernetLogLn("ETH Started");
      //set eth hostname here
      ETH.setHostname("esp32-ethernet");
      break;
    case SYSTEM_EVENT_ETH_CONNECTED:
      EthernetLogLn("ETH Connected");
      break;
    case SYSTEM_EVENT_ETH_GOT_IP:
      EthernetLog("ETH MAC: ");
      EthernetLog(ETH.macAddress());
      EthernetLog(", IPv4: ");
      EthernetLog(ETH.localIP());
      if (ETH.fullDuplex()) {
        EthernetLog(", FULL_DUPLEX");
      }
      EthernetLog(", ");
      EthernetLog(ETH.linkSpeed());
      EthernetLogLn("Mbps");
      eth_connected = true;
      break;
    case SYSTEM_EVENT_ETH_DISCONNECTED:
      EthernetLogLn("ETH Disconnected");
      eth_connected = false;
      break;
    case SYSTEM_EVENT_ETH_STOP:
      EthernetLogLn("ETH Stopped");
      eth_connected = false;
      break;
    default:
      break;
  }
}

void initEthernet()
{
  WiFi.onEvent(WiFiEvent);
  ETH.begin();
}
